#include<GL/glew.h> 
#include<GLFW/glfw3.h>
#include<iostream>
#include<fstream>
#include <string>  //for getline
#include<sstream> //string stream

#include"shaderClass.h"
#include"EBO.h"
#include"VAO.h"
#include"VBO.h"

#include"errorCheck.h"


int main()
{
	GLFWwindow* window;



	if (!glfwInit())
		return -1;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	


	window = glfwCreateWindow(780, 880, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	if(glewInit() != GLEW_OK)   //glewinit only after valid window context
		std::cout << "glew not ok" << std::endl;



	//float position[] = {
	//			-0.5f, -0.5f,
	//			1.0f,0.0f,0.0f,

	//			0.5f,   -0.5f,
	//			0.0f,0.0f,1.0f,

	//			0.5f,  0.5f,
	//			0.0f,1.0f,0.0f,

	//			-0.5f,  0.5f,
	//			0.0f,1.0f,0.0f

	//};

	/*GLuint indexes[] = {
		0,1,2,
		2,3,0
	};
*/

	/*GLfloat position[9] = {
					-0.5f, -0.5f,	0.0f,

					0.5f,  -0.5f,	0.0f,

					0.5f,	0.5f,	0.0f

							};
*/









	GLfloat vertices[] =
	{ 
		-1.0f, 0.0f,  1.0f,		1.0f, 0.0f, 0.0f,	
		-1.0f, 0.0f, -1.0f,		0.0f, 0.8f, 0.0f,	
		 1.0f, 0.0f, -1.0f,		0.0f, 0.4f, 0.0f,	
		 1.0f, 0.0f,  1.0f,		0.0f, 0.0f, 0.6f	
	};

	// Indices for vertices order
	GLuint indexes[] =
	{
		0, 1, 2,
		0, 2, 3
	};
	
	shader shaderProgram("default.vert", "default.frag");
	shaderProgram.Activate();
	VAO VAO1;
	VAO1.Bind();
	

	//VBO VBO1(rectangleVertices, sizeof(rectangleVertices));
	VBO VBO1(vertices, sizeof(vertices));
	EBO EBO1(indexes, sizeof(indexes));

	VAO1.linkAttrib(VBO1, 0, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6, 0);
	VAO1.linkAttrib(VBO1, 1, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6,(void*) (sizeof(float)*6));

	//VAO1.Bind();
	VAO1.Unbind();
	VBO1.Unbind();
	EBO1.Unbind();
	

	
	

	glEnable(GL_DEPTH_TEST);
	//glClearColor(0.07f, 0.13f, 0.17f, 1.0f);

	while (!glfwWindowShouldClose(window))
	{
		
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
		
		shaderProgram.Activate();
		VAO1.Bind();
		//glDrawArrays(GL_TRIANGLES, 0, 6);
		// Draw primitives, number of indices, datatype of indices, index of indices
		
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
		
		glfwSwapBuffers(window);


		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	VAO1.Delete();
	VBO1.Delete();
	EBO1.Delete();

	shaderProgram.Delete();

	glfwTerminate();

	return 0;
}





//
//
//
//
//#include<GL/glew.h> // include glew before anything related to opengl
////define glewstatic ...proj properties ..preprocessor dir ..defination add GLEW_STATIC
//#include<GLFW/glfw3.h>
//#include<iostream>
//#include<fstream>
//#include <string>  //for getline
//#include<sstream> //string stream
//
//
//
//struct ShaderSource {
//	std::string veretxSource;
//	std::string fragmentSource;
//
//};
//static ShaderSource parseShader(const std::string& filepath) {
//
//	std::ifstream stream(filepath);
//
//	enum class ShaderType {
//
//		None = -1, vertex = 0, fragment = 1
//
//	};
//
//	ShaderType type = ShaderType::None;
//
//
//	std::string line;
//	std::stringstream ss[2];
//
//	while (getline(stream, line)) {
//		if (line.find("#shader") != std::string::npos) {
//			if (line.find("vertex") != std::string::npos)
//				//set to vertex mode
//				type = ShaderType::vertex;
//
//			else if (line.find("fragment") != std::string::npos)
//				//set to fragment
//				type = ShaderType::fragment;
//		}
//
//		else {
//			ss[(int)type] << line << '\n';  //typecasting to int  ...type either fragment=1 or vertex=0, shader as defined on enum class..
//		}
//	}
//
//	return { ss[0].str(),ss[1].str() }; // ss[].str() --to get and set string object whose content is present in stream.
//}
//
//
//
//
//
//
//
//static unsigned int CompileShader(unsigned int type, const std::string& source) {
//	unsigned int id = glCreateShader(type);
//	const char* src = source.c_str();   // its basically &source[0]..pointer to begining of data
//	glShaderSource(id, 1, &src, nullptr);
//	glCompileShader(id);
//
//
//	//error handling
//	int result;
//	glGetShaderiv(id, GL_COMPILE_STATUS, &result);
//
//	if (result == GL_FALSE) {
//		int length;
//		glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
//		char* message = (char*)alloca(length * sizeof(char));
//		glGetShaderInfoLog(id, length, &length, message);
//		std::cout << "failed compile" << (type == GL_VERTEX_SHADER ? "vetrex" : "fragment") << "shader" << std::endl;
//		std::cout << message << std::endl;
//
//		glDeleteShader(id);
//
//	}
//
//	return id;
//}
//
//static unsigned int CreateShader(const std::string& vertexShader, const std::string& fragmentShader) {
//	unsigned int program = glCreateProgram();
//	unsigned int vs = CompileShader(GL_VERTEX_SHADER, vertexShader);
//	unsigned int fs = CompileShader(GL_FRAGMENT_SHADER, fragmentShader);
//
//	glAttachShader(program, vs);
//	glAttachShader(program, fs);
//	glLinkProgram(program);
//	glValidateProgram(program);
//
//	glDeleteShader(vs); //deleting the intermidiate 0bj files
//	glDeleteShader(fs);
//
//	return program;
//
//
//}
//
//
//
//
//int main(void)
//{
//	GLFWwindow* window;
//
//
//
//	if (!glfwInit())
//		return -1;
//
//
//	window = glfwCreateWindow(780, 480, "Hello World", NULL, NULL);
//	if (!window)
//	{
//		glfwTerminate();
//		return -1;
//	}
//
//	/* Make the window's context current */
//	glfwMakeContextCurrent(window);
//
//	if (glewInit() != GLEW_OK)   //glewinit only after valid window context
//		std::cout << "glew not ok" << std::endl;
//
//	//buffer
//	float position[] = {
//				-0.5f, -0.5f,
//				1.0f,0.0f,0.0f,
//
//				0.5f,   -0.5f,
//				0.0f,0.0f,1.0f,
//
//				0.5f,  0.5f,
//				0.0f,1.0f,0.0f,
//
//				-0.5f,  0.5f,
//				0.0f,0.0f,0.0f
//
//	};
//
//	unsigned int indices[] = {
//		0,1,2,
//		2,3,0
//	};
//
//
//
//	unsigned int buffer;
//	glGenBuffers(1, &buffer); //generate buffer
//	glBindBuffer(GL_ARRAY_BUFFER, buffer); //target
//	glBufferData(GL_ARRAY_BUFFER, sizeof(position), position, GL_STATIC_DRAW);
//
//
//	glEnableVertexAttribArray(0);
//	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), 0); //5*size.. stride,,size for  vertex from start to the begining of next vertex
//
//	glEnableVertexAttribArray(1);
//	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (char*)(sizeof(float) * 2));//stride here for next color position
//	// last parmeter .. stride to reach from vertices to color..type cast needed... 
//	//here after two vertices we reach to colorvertex
//
//	unsigned int index_buff;
//	glGenBuffers(1, &index_buff);
//	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buff);
//	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * 6, indices, GL_STATIC_DRAW);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//	//0,2  ...2 indiacted vec2 its type casted to vec2  for vec4 position in vertexshader
//	//gl_position is vec4
//	//location=0  must match the first parameter of vertexattribpoint
//	std::string vertexShader =
//		"#version 330 core\n"
//		"\n	"
//		"layout(location=0)in vec4 position;"
//		"\n	"
//		"void main()\n"
//		"{\n"
//		"gl_Position=position;\n"
//		"}\n";
//
//	std::string fragmentShader =
//		"#version 330 core\n"
//		"\n	"
//		"layout(location=0) out vec4 color;"
//		"\n	"
//		"void main()\n"
//		"{\n"
//		"color=vec4(1.0,0.0,0.0,1.0);\n"
//		"}\n";
//
//	//color RGBA
//	unsigned int shader = CreateShader(vertexShader, fragmentShader);
//
//
//
//
//	//ShaderSource source = parseShader("Basic.shader");
//	//unsigned int shader = CreateShader(source.veretxSource, source.fragmentSource);
//
//
//
//	glUseProgram(shader); //binding shader
//
//
//	glClearColor(0.07, 0.13, 0.17, 1.0);
//
//	while (!glfwWindowShouldClose(window))
//	{
//		/*
//		glBegin(GL_TRIANGLES);
//		glVertex2f(-0.5f, -0.5f);
//		glVertex2f(0.0f,   0.5f);
//		glVertex2f(0.5f,  -0.5f);
//		glEnd();
//		*/
//
//
//		//glDrawArrays(GL_TRIANGLES, 0, 3);
//
//		glClear(GL_COLOR_BUFFER_BIT);// two color buffer..front and back if not cleared when updating previous state is also dsiplayed
//		//glclear is expensive ...use as glClear(gl depth buffer | colorbuffer)
//		//glDrawArrays(GL_TRIANGLES, 0, 3);
//
//
//		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr); // last parm is nullptr as index buffer is already bound
//
//		glfwSwapBuffers(window);
//
//
//		glfwPollEvents();
//	}
//
//	glDeleteProgram(shader);
//
//	glfwTerminate();
//	return 0;
//}